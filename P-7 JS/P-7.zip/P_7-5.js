function sayWelcome(){
	alert("Welcome you all to Division of Information Technology")
	}
	
 